# ByteGG python!
This project allows you to:
- Easily bypass certain Roblox services, such as executors and scripts.
- Bypass ad links, including Linkvertise and Lootlinks.

### Installation Instructions
```bash
pip install bytegg
```

### Usage Examples

There is only one premium version available, and it requires an API key. For more information, send a direct message to "icmecodes" to obtain and purchase the key.

```python
import bytegg

async def bypass(url):
    xd = await bytegg.bypass(url=url, api_key='Delorean_M23981193209875491345103451015000998N')
    print(xd)

asyncio.run(bypass("https://linkvertise.com/1160317/pastedrop-evon-and-vega-x?o=sharing"))
```

### License
Distributed under the MIT License. See `LICENSE` for more information.

### Credits and Acknowledgments
Special thanks to icmecodes for the initial concept and to all beta testers who provided essential feedback.

### Contact
Contact me, rlow._. on discord