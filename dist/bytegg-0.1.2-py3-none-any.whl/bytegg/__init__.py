"""
ByteGG: A Python library for bypassing ad links and Roblox services.

This library provides functions for bypassing ad links and Roblox services,
making it easier to access content without the hassle of dealing with
annoying ads and restrictions.
"""

from .core import bypass

__version__ = "0.1.2"
